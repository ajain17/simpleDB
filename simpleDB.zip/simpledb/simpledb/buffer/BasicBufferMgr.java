package simpledb.buffer;
import java.util.Hashtable;
import java.util.Set;
import java.util.Enumeration;

import simpledb.file.*;
import simpledb.server.SimpleDB;

/**
 * Manages the pinning and unpinning of buffers to blocks.
 * @author Edward Sciore
 *
 */
class BasicBufferMgr {
	   private Buffer[] bufferpool;
	   private int numAvailable;
       private Hashtable<Block,Buffer> bPool = new Hashtable<Block,Buffer>();
       private static final long CRP =2;
       private int k=3;
   
   /**
    * Creates a buffer manager having the specified number 
    * of buffer slots.
    * This constructor depends on both the {@link FileMgr} and
    * {@link simpledb.log.LogMgr LogMgr} objects 
    * that it gets from the class
    * {@link simpledb.server.SimpleDB}.
    * Those objects are created during system initialization.
    * Thus this constructor cannot be called until 
    * {@link simpledb.server.SimpleDB#initFileAndLogMgr(String)} or
    * is called first.
    * @param numbuffs the number of buffer slots to allocate
    */
       BasicBufferMgr(int numbuffs) {
    	      bufferpool = new Buffer[numbuffs];
    	      numAvailable = numbuffs;
    	      System.out.println("number of buffers available:"+numbuffs);
    	      for (int i=0; i<numbuffs; i++)
    	      {
    	         bufferpool[i] = new Buffer(k);
    	                  System.out.print(bufferpool[i]+" ");
    	 	  }
    	      System.out.println();
    	   }
  
   
   /**
    * Flushes the dirty buffers modified by the specified transaction.
    * @param txnum the transaction's id number
    */
   synchronized void flushAll(int txnum) {
	   
	   for (Buffer buff : bufferpool)
	         if (buff.isModifiedBy(txnum))
	         {
	         buff.flush();
	         Enumeration <Block>e = bPool.keys();
	         while(e.hasMoreElements())
	         {
	        	 Block b1 = e.nextElement();
	        	 if(bPool.get(b1)==buff)
	        	 {
	        		 bPool.remove(b1);
	        	 }
	         }
	         }
	   }
	   
   /**
    * Pins a buffer to the specified block. 
    * If there is already a buffer assigned to that block
    * then that buffer is used;  
    * otherwise, an unpinned buffer from the pool is chosen.
    * Returns a null value if there are no available buffers.
    * @param blk a reference to a disk block
    * @return the pinned buffer
    */
   synchronized Buffer pin(Block blk) {
      Buffer buff = findExistingBuffer(blk);
      if (buff == null) {
    	  System.out.println("Page Miss Time " + System.currentTimeMillis());
         buff = chooseUnpinnedBuffer();
         if (buff == null)
            return null;
         buff.assignToBlock(blk);       //Reads the contents of the specified block into the buffer's page.
         bPool.put(blk, buff);
         bufferpool[numAvailable-1]=buff;
         for (int i=0; i<numAvailable; i++)
	      {
	          System.out.print("bufferpool is:"+bufferpool[i]+" ");
	 	  }
         
      }
      if (!buff.isPinned())
         numAvailable--;
      buff.pin();
      return buff;
   }
   
   /**
    * Allocates a new block in the specified file, and
    * pins a buffer to it. 
    * Returns null (without allocating the block) if 
    * there are no available buffers.
    * @param filename the name of the file
    * @param fmtr a pageformatter object, used to format the new block
    * @return the pinned buffer
    */
   synchronized Buffer pinNew(String filename, PageFormatter fmtr) {
      Buffer buff = chooseUnpinnedBuffer();
      
      if (buff == null)
         return null;
      buff.assignToNew(filename, fmtr);
      numAvailable--;
      bPool.put(buff.block(), buff);
      buff.pin();
      return buff;
   }
 
   
   /**
    * Unpins the specified buffer.
    * @param buff the buffer to be unpinned
    */
   synchronized void unpin(Buffer buff) {
   buff.unpin();
   if (!buff.isPinned())      //if pin > 0 is false means pin = 0. so make it available
   {
      numAvailable++;
   Enumeration <Block>e = bPool.keys();
   while(e.hasMoreElements())
   {
 	  Block b1 = e.nextElement();
       if(bPool.get(b1)==buff)
       {
        bPool.remove(b1);
       }
   }
   }
}
   
   /**
    * Returns the number of available (i.e. unpinned) buffers.
    * @return the number of available buffers
    */
   int available() {
      return numAvailable;
   }
   
   private Buffer findExistingBuffer(Block blk) {
	   
	   //Testing of task1-->to check for task1 uncomment the lines that say "uncomment this"
	   //this code uses hashmap for traversal which is an improvement over use of an array
	   //uncomment this-->//System.out.println("time before search through hashtable "+ System.nanoTime());
	   Buffer buff = (Buffer)bPool.get(blk);
	   //uncomment this-->System.out.println("time after search through hashtable "+ System.nanoTime());
	   System.out.println(blk.toString()); 
	   System.out.println("Buffer chosen:"+buff);
	   if(buff!=null)
	   {
		   long currentTime = System.currentTimeMillis();
		   if(currentTime - buff.getLastReference() > CRP)
		   {
			   long pageCrp = buff.getLastReference()-buff.getHistory(0);
			   for(int count = k-1; count>0; count--)
			   {
				   buff.setHistory(count, buff.getHistory(count-1)+ pageCrp);
			   }
				   buff.setHistory(0, currentTime);
				   buff.setLastReference(currentTime);
			   }
		   else
		   {
			   buff.setLastReference(currentTime);
		   }
		    System.out.println("After:");
		    System.out.println("History of buffer chosen:");
		    for(int j=k-1;j>=0;j--){
		    	if(buff.getHistory(j)!=0)
		    	    System.out.println((j+1)+"th last reference time is:"+buff.getHistory(j));}

		   return buff;
	   }
	   else return null;
	   }
   /*
    * this is the code for testing task1 if an array was used instead of hashmap
    * uncomment this to check for task1 using array
  	   private Buffer findExistingBuffer(Block blk) {
	   Buffer buff = null;
	   System.out.println("time before search through array "+ System.nanoTime()); 
	   for (Buffer buff1 : bufferpool) {
	         Block b = buff1.block();
	         if (b != null && b.equals(blk))
	         { buff = buff1;}
	         else buff = null;
	      }
	   System.out.println("time after search through array "+ System.nanoTime()); 
	   System.out.println("Buffer chosen:"+buff);
	   if(buff!=null)
	   {
		   long currentTime = System.currentTimeMillis();
		   if(currentTime - buff.getLastReference() > CRP)
		   {
			   long pageCrp = buff.getLastReference()-buff.getHistory(0);
			   for(int count = k-1; count>0; count--)
			   {
				   buff.setHistory(count, buff.getHistory(count-1)+ pageCrp);
			   }
				   buff.setHistory(0, currentTime);
				   buff.setLastReference(currentTime);
			   }
		   else
		   {
			   buff.setLastReference(currentTime);
		   }
		    System.out.println("After:");
		    System.out.println("History of buffer chosen:");
		    for(int j=k-1;j>=0;j--){
		    	if(buff.getHistory(j)!=0)
		    	    System.out.println((j+1)+"th last reference time is:"+buff.getHistory(j));}

		   return buff;
	   }
	   else return null;
	   }

   /*
    */
  
   private Buffer chooseUnpinnedBuffer() {
	 
	   long currentTime =  System.currentTimeMillis();
	   long minimumTime = currentTime;
	   Buffer victim = null;
	      for (Buffer buff : bufferpool)
		   if(!buff.isPinned() && currentTime-buff.getLastReference()>CRP && buff.getHistory(k-1)<minimumTime)
		   {
			   minimumTime = buff.getHistory(k-1);
			   victim = buff;
		   }
	     
	      if(victim!=null){
	        	  System.out.println("buffer chosen:"+victim);
		  
		   for(int count = k-1; count>0; count--)
		   {
			   victim.setHistory(0, currentTime);
		   }
		   victim.setHistory(0, currentTime);
		   victim.setLastReference(currentTime);
	    System.out.println("After:");
	    System.out.println("history of buffer chosen:");
		    for(int j=k-1;j>=0;j--)
		    {
		    	if(victim.getHistory(j)!=0)
		    System.out.println((j+1)+"th last reference of the buffer chosen: "+victim.getHistory(j));
		    }  return victim;
		   
	   }
		   return null;
  }
			  
}
