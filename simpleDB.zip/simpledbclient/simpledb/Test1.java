package simpledb;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.*;

import simpledb.file.Page;
import simpledb.remote.SimpleDriver;

public class Test1 {
	
public static void main(String args[])
	{
	Connection conn = null;
	try {
		// Step 1: connect to database server
		Driver d = new SimpleDriver();
		conn = d.connect("jdbc:simpledb://localhost", null);
		
		Page p=new Page();
		
		//testing int
		p.setInt(1, 241);
		p.setInt(89, 132);
		System.out.println("testing int:"+p.getInt(89));

		//testing boolean
		p.setBoolean(5, true);
		System.out.println("testing boolean:"+p.getBoolean(5));
		
		//testing byte
		byte[] b={(byte)127,(byte)12};
		p.setBytes(8,b);
		byte v[]=p.getBytes(8);
		for(int i=0;i<b.length;i++)
		{
		System.out.println("testing byte:"+v[i]);
		}
		
		//testing short
		p.setShort(80,(short)20); //in java values are by default int if written short x=12, in order to represent as short we need to typecast
		System.out.println("testing short:"+p.getShort(80));
		
		
		//typecasting byte-->int
		int x=b[1];
		p.setInt(9, x);
		System.out.println("testing typecasting byte-->int:"+p.getInt(9));
		
		//typecasting int-->byte 
		//132 in int=-124 in bytes 
		byte itob[]={(byte)p.getInt(89)}; 
		p.setBytes(10,itob);
		byte i1[]=p.getBytes(10);
		System.out.println("testing typecasting int-->byte:"+i1[0]);
		
		
		//testing date		
		p.setDate(20,new Date());
		System.out.println("testing date:"+p.getDate(20));
		
		//changing month to test Date
		p.setDate(21,new Date());
		Date m=p.getDate(21);
		m.setMonth(7);  //changing month to august
		m.setYear(25);  //changing year to 1925
		p.setDate(45,m);
		System.out.println("Changing month in current date:"+p.getDate(45));
		
		//testing string
		p.setString(22,"vineeta");
		System.out.println("testing string:"+p.getString(22));
				
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	finally {
		// Step 4: close the connection
		try {
			if (conn != null)
				conn.close();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}

                }
	}
}
